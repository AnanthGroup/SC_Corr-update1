#!/bin/bash
sed -i 's/timecorr.f90/FF_MQC_timecorr_mD.f90/g' Makefile
sed -i 's/supply.f90/supply_mD.f90/g' Makefile
sed -i 's/traj.f90/traj_mD.f90/g' Makefile
sed -i 's/MonteCarlo.f90/MonteCarlo_mD.f90/g' Makefile
sed -i 's/params/params_mD/g' Makefile
sed -i 's/potential.f90/potential_mD.f90/g' Makefile

sed -i 's/FF_Bq/FF_Bp/g' FF_MQC_timecorr_mD.f90
sed -i 's/posn/mom/g' FF_MQC_timecorr_mD.f90

sed -i 's/vdv/vdv_AnHO/g' supply_mD.f90
sed -i 's/vdv/vdv_AnHO/g' traj_mD.f90
