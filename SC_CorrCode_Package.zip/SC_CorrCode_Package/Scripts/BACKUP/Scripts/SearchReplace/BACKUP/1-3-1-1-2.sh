#!/bin/bash
sed -i 's/timecorr.f90/FF_MQC_timecorr_1D.f90/g' Makefile
sed -i 's/supply.f90/supply_1D.f90/g' Makefile
sed -i 's/traj.f90/traj_1D.f90/g' Makefile
sed -i 's/MonteCarlo.f90/MonteCarlo_1D.f90/g' Makefile
sed -i 's/params/params_1D/g' Makefile
sed -i 's/potential.f90/potential_1D.f90/g' Makefile

sed -i 's/vdv/vdv_AnHO/g' supply_1D.f90
sed -i 's/vdv/vdv_AnHO/g' traj_1D.f90
