#!/bin/bash
rm -r EXPERIMENT
LINES=()
while IFS= read -r line
do
  LINES[${#LINES[@]}]="$line"
done < "theory.in"
Dimens=${LINES[1]}
Theory=${LINES[3]}
Implem=${LINES[5]}
Operat=${LINES[7]}
Potent=${LINES[9]}

if [ $Dimens -eq "-1" ]; then
cp -r Source_NonAdiabatic EXPERIMENT
exit
elif [ $Potent -gt "2" ]; then
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo 'Please enter 1 or 2 to specify the'
echo '"Model Potential" in "theory.in".'
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Potent -lt "1" ]; then
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo 'Please enter 1 or 2 to specify the'
echo '"Model Potential" in "theory.in".'
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Implem -gt "2" ]; then
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo 'Please enter 1 or 2 to specify the'
echo '"Implementation" in "theory.in".'
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Implem -lt "1" ]; then
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo 'Please enter 1 or 2 to specify the'
echo '"Implementation" in "theory.in".'
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Theory -gt "5" ]; then
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo 'Please use an integer in [1,5]'
echo 'to specify the "Level of theory" in'
echo '"theory.in".'
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Theory -lt "1" ]; then
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo 'Please use an integer in [1,5]'
echo 'to specify the "Level of theory" in'
echo '"theory.in".'
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Operat -lt "1" ]; then
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo 'Please input 1 or 2 for "Type of Observable"'
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Operat -gt "2" ]; then
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo 'Please input 1 or 2 for "Type of Observable"'
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Dimens -eq "0" ]; then
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo "Please input a positive number for"
echo "'Degrees of freedom' in file 'theory.in'"
echo
echo "Or enter '-1' for 'Degrees of freedom'"
echo "to generate the default nonadiabatic model"
echo "with DF MQC-IVR"
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Dimens -lt "-1" ]; then
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo "Please input a positive number for"
echo "system degrees of freedom in 'theory.in'"
echo
echo "Or enter '-1' for system degrees of freedom"
echo "to generate the default nonadiabatic model"
echo "with MQC-IVR"
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Theory -eq "1" -a $Implem -eq "2" ]; then   #Flag FB DHK-IVR
# NOTE: just send them to DF and notify
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo 'Forward-backward DHK-IVR has not been'
echo 'configured. Please use the Double-Forward'
echo 'setting.'
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Theory -eq "4" -a $Operat -eq "2" ]; then #Flag LSC-IVR with B=B(p)
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo 'LSC-IVR with a momentum operator'
echo 'has not been coded. Please use the'
echo 'position setting and, say, edit' 
echo 'your "supply_mD.f90" file to include'
echo 'the Wigner transform you need.'
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Theory -eq "2" -a $Implem -eq "2" ]; then #Flag FB Hus-IVR and LSC-IVR
#! NOTE: just set to DF and notify
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo 'With Husimi, LSC, and aMQC-IVR implementations,'
echo 'please use the Double-Forward Setting.'
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Theory -eq "5" -a $Implem -eq "2" ]; then #Flag FB Hus-IVR and LSC-IVR
#! NOTE: just set to DF and notify
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo 'With Husimi, LSC, and aMQC-IVR implementations,'
echo 'please use the Double-Forward Setting.'
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Theory -eq "4" -a $Implem -eq "2" ]; then #Flag FB Hus-IVR and LSC-IVR
# NOTE: just set to DF and notify
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo 'With Husimi, LSC, and aMQC-IVR implementations,'
echo 'please use the Double-Forward Setting.'
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Dimens -gt "1" -a "$Potent" -eq "1" ]; then #Flag Harmonic Pot with mD
#! NOTE: just set to anharmonic system
echo
echo
echo "### BEGIN ERROR MESSAGE ###"
echo
echo 'Please use the "anharmonic" option in "theory.in" and,'
echo 'if needed, edit the subroutine in "potential_mD.f90"'
echo 'to include the potential energy surface, forces, etc.'
echo 'of your choice.'
echo
echo "### END ERROR MESSAGE ###"
echo
echo
mkdir EXPERIMENT
exit
elif [ $Dimens -lt "3" ]; then
 cd Scripts/MoveFiles/
 sh $Dimens-$Theory-$Implem-$Operat.sh
 cp ../SearchReplace/$Dimens-$Theory-$Implem-$Operat-$Potent.sh ../../EXPERIMENT
 cd ../../EXPERIMENT
 sh $Dimens-$Theory-$Implem-$Operat-$Potent.sh
 rm *-$Potent.sh
 cd ../
else
 echo
 echo
 echo "### BEGIN WARNING MESSAGE ###"
 echo
 echo 'Note that only 1D and 2D model potentials are provided.'
 echo 'You will need to change the subroutine in '
 echo '"potential_mD.f90" if you are using 3 dofs or more'
 echo
 echo "### END WARNING MESSAGE ###"
 echo
 echo
 cd Scripts/MoveFiles/
 sh 2-$Theory-$Implem-$Operat.sh
 cp ../SearchReplace/2-$Theory-$Implem-$Operat-$Potent.sh ../../EXPERIMENT
 cd ../../EXPERIMENT
 sh 2-$Theory-$Implem-$Operat-$Potent.sh
 rm *-$Potent.sh
 cd ../
fi
