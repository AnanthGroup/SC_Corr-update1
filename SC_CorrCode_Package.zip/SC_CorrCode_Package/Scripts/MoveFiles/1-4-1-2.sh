#!/bin/bash
mkdir ../../EXPERIMENT
cp ../jobrun.sh ../../EXPERIMENT
cd ../../
cp makefiles/Makefile EXPERIMENT
cp supply/supply_1D.f90 EXPERIMENT
cp params/params_1D.f90 EXPERIMENT
cp timecorr/LSC_timecorr_1D.f90 EXPERIMENT
cp traj/traj_1D.f90 EXPERIMENT
cp monteCarlo/MonteCarlo_1D.f90 EXPERIMENT
cp potentials/potential_1D.f90 EXPERIMENT
cp theory.in input_1D
mv input_1D EXPERIMENT
cd Scripts/MoveFiles
