#!/bin/bash
mkdir ../../EXPERIMENT
cp ../jobrun.sh ../../EXPERIMENT
cd ../../
cp Source_Adiabatic/makefiles/Makefile EXPERIMENT
cp Source_Adiabatic/supply/supply_mD.f90 EXPERIMENT
cp Source_Adiabatic/params/params_mD.f90 EXPERIMENT
cp Source_Adiabatic/timecorr/multiD/LSC_timecorr_mD.f90 EXPERIMENT
cp Source_Adiabatic/traj/traj_mD.f90 EXPERIMENT
cp Source_Adiabatic/monteCarlo/MonteCarlo_mD.f90 EXPERIMENT
cp Source_Adiabatic/potentials/potential_mD.f90 EXPERIMENT
cp theory.in input_mD
mv input_mD EXPERIMENT
cd Scripts/MoveFiles
